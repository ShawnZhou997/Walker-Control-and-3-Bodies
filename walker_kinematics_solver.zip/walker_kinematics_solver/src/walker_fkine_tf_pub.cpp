/*************************************************************************************
*
*   Description：订阅Walker左/右臂关节角、末端位姿;
*   Author     ：summer(LiXiao)
*   Data       ：2020.08.15
*   Modify     ：Hank 发布末端实时tf
*   Data       ：2020.08.28
*
************************************************************************************/
#include <ros/ros.h>
#include <iostream>
#include <fstream>

#include <vector>
#include <cmath>
#include <sensor_msgs/JointState.h>
#include <eigen3/Eigen/Core>
#include <eigen3/Eigen/Dense>
//tf变换头
#include <tf/transform_listener.h>
#include <tf/transform_broadcaster.h>
#include <geometry_msgs/TransformStamped.h>
#include "walker_kinematics_solver/walker_kinematics_solver.h"

using namespace std;
using namespace Eigen;

VectorXd left_position(7),left_velocity(7),left_effort(7);
VectorXd right_position(7),right_velocity(7),right_effort(7);
bool left_flag = false,right_flag = false; //是否接收到关节信息的标记

/***************** 回调函数 *****************/
// 左臂关节状态订阅
void subWalker_leftLimb(const sensor_msgs::JointState &msgs) {
    for(int i=0;i<7;i++) {
        left_position(i) = msgs.position[i];
        left_velocity(i) = msgs.velocity[i];
        left_effort(i) = msgs.effort[i];
    }
    left_flag = true;
}

// 右臂关节状态订阅
void subWalker_rightLimb(const sensor_msgs::JointState &msgs) {
    for(int i=0;i<7;i++) {
        right_position(i) = msgs.position[i];
        right_velocity(i) = msgs.velocity[i];
        right_effort(i) = msgs.effort[i];
    }
    right_flag = true;
}

int main (int argc, char** argv)
{
    ros::init(argc, argv, "walker_fkine_tf_pub");
    ros::NodeHandle nh;
    ros::Rate loop_rate(100);

    // 左臂关节话题订阅
    ros::Subscriber walker_leftLimb_states_sub =
        nh.subscribe("/walker/leftLimb/joint_states", 1000, &subWalker_leftLimb);

    // 右臂关节话题订阅
    ros::Subscriber walker_rightLimb_states_sub =
        nh.subscribe("/walker/rightLimb/joint_states", 1000, &subWalker_rightLimb);

    ros::Duration(0.5).sleep(); //等待话题注册

    // 测试是否订阅关节角
    while(!(left_flag && right_flag) && ros::ok())
    {
        cout << "Walker未启动..." << endl;
        ros::spinOnce();
        loop_rate.sleep();
    }

    //发布TF
    tf::TransformBroadcaster br;

    cout << "上肢tf发布中..." << endl;

    //定义一个求解器
    WalkerKinematicsSolver solver;

    while(ros::ok())
    {
        ros::spinOnce();

        VectorXd temp_left_position = left_position;
        VectorXd temp_right_position = right_position;

        //获取当前左臂臂末端位姿
        geometry_msgs::Pose left_hand_pose, right_hand_pose;
        left_hand_pose = solver.getLeftEEPoseInBase(temp_left_position);
        right_hand_pose = solver.getRightEEPoseInBase(temp_right_position);

        //发布实时TF
        geometry_msgs::TransformStamped tfs_left, tfs_right;

        tfs_left.header.stamp = ros::Time::now();
        tfs_left.header.frame_id = "torso_base_link";
        tfs_left.child_frame_id = "left_hand_center_link";
        tfs_left.transform.translation.x = left_hand_pose.position.x;
        tfs_left.transform.translation.y = left_hand_pose.position.y;
        tfs_left.transform.translation.z = left_hand_pose.position.z;
        tfs_left.transform.rotation.x = left_hand_pose.orientation.x;
        tfs_left.transform.rotation.y = left_hand_pose.orientation.y;
        tfs_left.transform.rotation.z = left_hand_pose.orientation.z;
        tfs_left.transform.rotation.w = left_hand_pose.orientation.w;

        tfs_right.header.stamp = ros::Time::now();
        tfs_right.header.frame_id = "torso_base_link";
        tfs_right.child_frame_id = "right_hand_center_link";
        tfs_right.transform.translation.x = right_hand_pose.position.x;
        tfs_right.transform.translation.y = right_hand_pose.position.y;
        tfs_right.transform.translation.z = right_hand_pose.position.z;
        tfs_right.transform.rotation.x = right_hand_pose.orientation.x;
        tfs_right.transform.rotation.y = right_hand_pose.orientation.y;
        tfs_right.transform.rotation.z = right_hand_pose.orientation.z;
        tfs_right.transform.rotation.w = right_hand_pose.orientation.w;

        // //上肢torso_base_link到base_footprint的固定变换
        // geometry_msgs::TransformStamped tfs_upper2footprint;
        // tfs_upper2footprint.header.stamp = ros::Time::now();
        // tfs_upper2footprint.header.frame_id = "base_footprint";
        // tfs_upper2footprint.child_frame_id = "torso_base_link";
        // tfs_upper2footprint.transform.translation.x = 0;
        // tfs_upper2footprint.transform.translation.y = 0;
        // tfs_upper2footprint.transform.translation.z = 1.10976;
        // tfs_upper2footprint.transform.rotation.x = 0;
        // tfs_upper2footprint.transform.rotation.y = 0;
        // tfs_upper2footprint.transform.rotation.z = 0;
        // tfs_upper2footprint.transform.rotation.w = 1;

        br.sendTransform(tfs_left);
        br.sendTransform(tfs_right);
        // br.sendTransform(tfs_upper2footprint);

        loop_rate.sleep();
    }

    return 0 ;
}
