﻿///20231113_zsx
//求解器求逆解，并通过话题发布
#include <ros/ros.h>
#include <stdio.h>
#include <iostream>
#include <Eigen/Dense>
#include <sys/time.h>
#include <geometry_msgs/Pose.h>
#include "walker_kinematics_solver/walker_kinematics_solver.h"
#include <sensor_msgs/JointState.h>


#include <chrono>
using namespace chrono;

int main(int argc, char **argv)
{
    ros::init(argc, argv, "ik_api_node");
    ros::NodeHandle n("~");
    ros::AsyncSpinner spinner(2);
    spinner.start();

    //定义一个求解器对象
    WalkerKinematicsSolver solver;

    // 创建发布器
    ros::Publisher left_ikfk_pub = n.advertise<sensor_msgs::JointState>("left_ikfk_pose", 10);
    ros::Publisher right_ikfk_pub = n.advertise<sensor_msgs::JointState>("right_ikfk_pose", 10);


    while (ros::ok())
    {
        /*左臂部分：
        用已有赋值的关节角去求正解，得末端位姿；
        再用末端位姿求逆解，得关节角；
        最后用逆解结果和手动赋的初值作比较*/
        /*************末端正解测试*****************/
        //左臂预期关节角赋值
        VectorXd left_q_expect(7);
        left_q_expect << 0.5, -0.8, -0.45, -1.5, 0.0, 0.0, 0.0;

        //获取左臂末端相对base_link的正解位姿
        geometry_msgs::Pose left_fk_pose;
        left_fk_pose = solver.getLeftEEPoseInBase(left_q_expect);
        //cout << "1. 左臂末端相对base_link的正解位姿：\n" << left_fk_pose << endl;
        /*************【所有关节】正解测试*****************/
        // vector<geometry_msgs::Pose> left_all_pose;
        // left_all_pose = solver.getLeftAllPoseInBase(left_q_expect);
        //cout << "3. 左臂各关节相对base_link的正解位姿：\n";
        // for(int i=0; i<left_all_pose.size(); ++i)
        // {
        //     cout << "坐标系" << i+1 << "：\n" << left_all_pose[i] << endl;
        // }
        //cout << "--------------------" << endl;
        /*************【最优】反解测试：用正解结果测试反解*****************/
        VectorXd left_ik_value;
        bool success1 = solver.getLeftBestIkFromPoseInBase(left_fk_pose, left_ik_value);
        // printf("5. 左臂最优反解值：\n");
        // cout << left_ik_value.transpose() << endl;

        // printf("5. 左臂最优反解值正解结果：\n");
        // geometry_msgs::Pose left_ikfk_pose = solver.getLeftEEPoseInBase(left_ik_value);
        // cout << left_ikfk_pose << endl;
        // // printf("5. 左臂最优反解值正解结果与输入值的误差：\n");
        // VectorXd left_ikfk_err(7);
        // left_ikfk_err << (left_ikfk_pose.position.x - left_fk_pose.position.x),
        //         (left_ikfk_pose.position.y - left_fk_pose.position.y),
        //         (left_ikfk_pose.position.z - left_fk_pose.position.z),
        //         (left_ikfk_pose.orientation.x - left_fk_pose.orientation.x),
        //         (left_ikfk_pose.orientation.y - left_fk_pose.orientation.y),
        //         (left_ikfk_pose.orientation.z - left_fk_pose.orientation.z),
        //         (left_ikfk_pose.orientation.w - left_fk_pose.orientation.w);
        // cout << left_ikfk_err.transpose() << endl;
        // cout << "--------------------" << endl;
        // ROS话题发布左臂的最优反解结果
        sensor_msgs::JointState left_fk_joint_state;
        left_fk_joint_state.header.stamp = ros::Time::now();
        left_fk_joint_state.name = {"left_limb_j1","left_limb_j2","left_limb_j3","left_limb_j4","left_limb_j5","left_limb_j6","left_limb_j7"};
        left_fk_joint_state.position = {left_ik_value[1],left_ik_value[2],left_ik_value[3],left_ik_value[4],left_ik_value[5],left_ik_value[6],left_ik_value[7]};

        left_ikfk_pub.publish(left_fk_joint_state);

        /*右臂部分*/
        //右臂预期关节角赋值
        VectorXd right_q_expect(7);
        right_q_expect << -0.7, -0.56,  0.52,  -1.2, -0.25,     0 ,    0;
        //获取右臂末端相对base_link的正解位姿
        geometry_msgs::Pose right_fk_pose;
        right_fk_pose = solver.getRightEEPoseInBase(right_q_expect);

        // vector<geometry_msgs::Pose> right_all_pose;
        // right_all_pose = solver.getRightAllPoseInBase(right_q_expect);
        // cout << "4. 右臂各关节相对base_link的正解位姿：\n";
        // for(int i=0; i<right_all_pose.size(); ++i)
        // {
        //     cout << "坐标系" << i+1 << "：\n" << right_all_pose[i] << endl;
        // }
        // cout << "--------------------" << endl;

        /*************【最优】反解测试：用正解结果测试反解*****************/
        VectorXd right_ik_value;
        bool success2 = solver.getRightBestIkFromPoseInBase(right_fk_pose, right_ik_value);
        // printf("6. 右臂最优反解值：\n");
        // cout << right_ik_value.transpose() << endl;

        // printf("6. 右臂最优反解值正解结果：\n");
        // geometry_msgs::Pose right_ikfk_pose = solver.getRightEEPoseInBase(right_ik_value);
        // cout << right_ikfk_pose << endl;

        // printf("6. 右臂最优反解值正解结果与输入值的误差：\n");
        // VectorXd right_ikfk_err(7);
        // right_ikfk_err << (right_ikfk_pose.position.x - right_fk_pose.position.x),
        //         (right_ikfk_pose.position.y - right_fk_pose.position.y),
        //         (right_ikfk_pose.position.z - right_fk_pose.position.z),
        //         (right_ikfk_pose.orientation.x - right_fk_pose.orientation.x),
        //         (right_ikfk_pose.orientation.y - right_fk_pose.orientation.y),
        //         (right_ikfk_pose.orientation.z - right_fk_pose.orientation.z),
        //         (right_ikfk_pose.orientation.w - right_fk_pose.orientation.w);
        // cout << right_ikfk_err.transpose() << endl;
        // cout << "--------------------" << endl;

        // ROS发布右臂的最优反解结果
        sensor_msgs::JointState right_fk_joint_state;
        right_fk_joint_state.header.stamp = ros::Time::now();
        right_fk_joint_state.name = {"right_limb_j1","right_limb_j2","right_limb_j3","right_limb_j4","right_limb_j5","right_limb_j6","right_limb_j7"};
        right_fk_joint_state.position = {right_ik_value[1],right_ik_value[2],right_ik_value[3],right_ik_value[4],right_ik_value[5],right_ik_value[6],right_ik_value[7]};

        right_ikfk_pub.publish(right_fk_joint_state);
    }
    return 0;
}
