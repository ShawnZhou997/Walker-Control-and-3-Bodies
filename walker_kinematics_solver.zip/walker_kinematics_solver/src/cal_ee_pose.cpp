#include <ros/ros.h>
#include <stdio.h>
#include <iostream>
#include <Eigen/Dense>
#include <sys/time.h>
#include <geometry_msgs/Pose.h>
#include "walker_kinematics_solver/walker_kinematics_solver.h"

int main(int argc, char **argv)
{
    ros::init(argc, argv, "cal_ee_pose");
    ros::NodeHandle n("~");
    ros::AsyncSpinner spinner(1);
    spinner.start();

    //定义一个求解器对象
    WalkerKinematicsSolver solver;
    VectorXd right_ik_value;

    //计算绕x转90度的四元数
    Matrix3d target_matrix = solver.calRotFromFixedRPY(90*M_PI/180, 0, 0);

    cout << target_matrix << endl;

    geometry_msgs::Pose right_fk_pose;
    right_fk_pose.position.x = 0.323632;
    right_fk_pose.position.y = 0.0732591;
    right_fk_pose.position.z = -0.25;
    right_fk_pose.orientation.x = 0;
    right_fk_pose.orientation.y =  0;
    right_fk_pose.orientation.z =  0;
    right_fk_pose.orientation.w = 1;

    gettimeofday(&timeStart, NULL); //获取当前绝对时间
    success = solver.getRightBestIkFromPoseInBase(right_fk_pose, right_ik_value);
    gettimeofday(&timeNow, NULL); //获取当前绝对时间
    t = (timeNow.tv_sec - timeStart.tv_sec) + (timeNow.tv_usec - timeStart.tv_usec)/1000.0; //计算算法耗时
    printf("6. 右臂最优反解耗时：【%.3fms】\n", t);

    printf("6. 右臂最优反解值：\n");
    cout << right_ik_value.transpose() << endl;

    // printf("6. 右臂最优反解值正解结果：\n");
    // geometry_msgs::Pose right_ikfk_pose = solver.getRightEEPoseInBase(right_ik_value);
    // cout << right_ikfk_pose << endl;

    printf("6. 右臂最优反解值正解结果与输入值的误差：\n");
    VectorXd right_ikfk_err(7);
    right_ikfk_err << (right_ikfk_pose.position.x - right_fk_pose.position.x),
            (right_ikfk_pose.position.y - right_fk_pose.position.y),
            (right_ikfk_pose.position.z - right_fk_pose.position.z),
            (right_ikfk_pose.orientation.x - right_fk_pose.orientation.x),
            (right_ikfk_pose.orientation.y - right_fk_pose.orientation.y),
            (right_ikfk_pose.orientation.z - right_fk_pose.orientation.z),
            (right_ikfk_pose.orientation.w - right_fk_pose.orientation.w);
    cout << right_ikfk_err.transpose() << endl;

    cout << "--------------------" << endl;

    return 0;
}
