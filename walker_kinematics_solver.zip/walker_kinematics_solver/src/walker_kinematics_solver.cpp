﻿#include <iostream>
#include <vector>
#include <string>
#include <math.h>
#include <stdio.h>
#include <iterator>
#include <algorithm>
#include <sys/time.h>
#include "walker_kinematics_solver/walker_kinematics_solver.h"

using namespace std;
using namespace Eigen;

//连杆类构造函数
Link::Link(double theta_, double d_, double a_, double alpha_)
{
	theta = theta_;
	d = d_;
	a = a_;
	alpha = alpha_;
}

//输出连杆参数
void Link::printLinkInfo()
{
	cout << "theta: " << theta << "\t d: " << d << "\t a: " << a << "\t alpha: " << alpha << endl;
}


//求解器类构造函数：公用变量初始化
WalkerKinematicsSolver::WalkerKinematicsSolver() //初始化连杆DH参数表
	: link1(-M_PI / 2,  -Dbs,   0,     M_PI / 2),
	  link2( M_PI / 2,   0,     0,     M_PI / 2),
	  link3( M_PI,       Dso,  -Deo,  -M_PI / 2),
	  link4( 0,          0,     Deo,   M_PI / 2),
	  link5( M_PI / 2,   Dow,   0,    -M_PI / 2),
	  link6(-M_PI / 2,   0,     0,     M_PI / 2),
	  link7( 0,          0,     Dwt,   0       )
{
	//初始化连杆向量
	//注意：Eigen Vector3d默认是列向量
	lbs_0 <<  0,    0,   -Dbs;
	lse_3 << -Deo, -Dso,  0;
	leo_4 <<  Deo,  0,    0;
	low_4 <<  0,    0,    Dow;
	lwt_7 <<  Dwt,  0,    0;
	
	//计算【左臂】坐标系0相对base_link的变换
	//旋转变换
	Matrix3d R_left0_base;
	R_left0_base = calRotFromFixedRPY(M_PI / 2 + 15 * deg_to_rad, 0, 0); //由walker结构得出
	//平移变换
	Vector3d t_left0_base;
	t_left0_base << 0, 0.17433, 0; //由walker结构得出
	//综合为齐次变换矩阵
	T_left0_base << R_left0_base, t_left0_base, 0, 0, 0, 1;

	//求base_link到左臂坐标系0的变换，也就是T_left0_base的逆变换
	T_base_left0 = T_left0_base.inverse();

	//计算【右臂】坐标系0相对base_link的变换
	//旋转变换
	Matrix3d R_right0_base;
	R_right0_base = calRotFromFixedRPY(M_PI / 2 + 15 * deg_to_rad, 0, M_PI); //由walker结构得出
	//平移变换
	Vector3d t_right0_base;
	t_right0_base << 0, -0.17433, 0; //由walker结构得出
	//综合为齐次变换矩阵
	T_right0_base << R_right0_base, t_right0_base, 0, 0, 0, 1;

	//求base_link到右臂坐标系0的变换，也就是T_right0_base的逆变换
	T_base_right0 = T_right0_base.inverse();

	//计算【夹爪】到【坐标系7——球腕】的变换，注意这一变换不分左右臂
	//平移变换
	Vector3d t_gripper_7;
	t_gripper_7 << 0.124, 0.035, 0;
    //旋转变换：绕C7 Z轴旋转45度
	Matrix3d R_gripper_7;
	R_gripper_7 = calRotFromFixedRPY(0, 0, M_PI / 4);
	//综合为齐次变换矩阵
	T_gripper_7 << R_gripper_7, t_gripper_7, 0, 0, 0, 1;

	//求计算【坐标系7——球腕】到【夹爪】的变换，也就是上一变换的逆变换，注意这一变换不分左右臂
	T_7_gripper = T_gripper_7.inverse();

}

//求相邻连杆间的旋转矩阵
//输入：theta——关节变量，即连杆实际旋转角度（包括初始角度在内）；alpha——关节扭角，属于固定结构参数，从DH参数表获取
//返回：旋转矩阵
Matrix3d WalkerKinematicsSolver::calRotMatrix(double theta, double alpha)
{
	Matrix3d R;
	R << cos(theta), -sin(theta)*cos(alpha),  sin(theta)*sin(alpha),
		 sin(theta),  cos(theta)*cos(alpha), -cos(theta)*sin(alpha),
		 0,           sin(alpha),             cos(alpha);
	return R;
}

//求相邻连杆间的齐次变换矩阵
//输入：theta——关节变量，即连杆实际旋转角度（包括初始角度在内）；d；a；alpha
//返回：齐次变换矩阵
Matrix4d WalkerKinematicsSolver::calTransMatrix(double theta, double d, double a, double alpha)
{
	Matrix4d T;
	T << cos(theta), -sin(theta)*cos(alpha),  sin(theta)*sin(alpha), a*cos(theta),
		 sin(theta),  cos(theta)*cos(alpha), -cos(theta)*sin(alpha), a*sin(theta),
		 0,           sin(alpha),             cos(alpha),            d,
		 0,           0,                      0,                     1;
	return T;
}

//求给定向量的反对称矩阵
//输入：三维向量x
//返回：3 * 3反对称矩阵u_hat
Matrix3d WalkerKinematicsSolver::calAntiMatrix(Vector3d x)
{
	Vector3d u = x / x.norm(); //求x向量的单位向量
	Matrix3d u_hat;
	//注意：Eigen的序号从0开始！
	u_hat << 0,    -u(2),  u(1),
		     u(2),  0,    -u(0),
		    -u(1),  u(0),  0;

	return u_hat;
}

//将按ZYX顺序，绕【运动坐标系轴】旋转的欧拉角转换为旋转矩阵
//输入：三轴旋转量
//返回：旋转矩阵
Matrix3d WalkerKinematicsSolver::calRotFromMovedZYX(double rz, double ry, double rx)
{
	//预先计算正余弦值
	double cz = cos(rz); double sz = sin(rz);
	double cy = cos(ry); double sy = sin(ry);
	double cx = cos(rx); double sx = sin(rx);

	//求等价旋转矩阵
	Matrix3d Rz, Ry, Rx, R;
	Rz << cz, -sz, 0,
		  sz,  cz, 0,
		  0,   0,  1;

	Ry << cy, 0, sy,
		  0,  1, 0,
		 -sy, 0, cy;

	Rx << 1, 0,   0, 
		  0, cx, -sx, 
	      0, sx,  cx;

	R = Rz*Ry*Rx;

	return R;
}

//将按XYZ顺序，绕【固定坐标系轴】旋转的RPY角转换为旋转矩阵（表达式与上个函数相同）
//输入：三轴旋转量
//返回：旋转矩阵
Matrix3d WalkerKinematicsSolver::calRotFromFixedRPY(double rx, double ry, double rz)
{
	//预先计算正余弦值
	double cz = cos(rz); double sz = sin(rz);
	double cy = cos(ry); double sy = sin(ry);
	double cx = cos(rx); double sx = sin(rx);

	//求等价旋转矩阵
	Matrix3d Rz, Ry, Rx, R;
	Rz << cz, -sz, 0,
		sz, cz, 0,
		0, 0, 1;

	Ry << cy, 0, sy,
		0, 1, 0,
		-sy, 0, cy;

	Rx << 1, 0, 0,
		0, cx, -sx,
		0, sx, cx;

	R = Rz*Ry*Rx;

	return R;
}

//基本正解函数：相对【坐标系0】，不直接使用，仅供左右臂正解函数调用
//输入：不分左右臂，预期关节转角（从theta的初始offset处开始计算，代码自动将其转换为从坐标系零点开始的转角）
//返回：不分左右臂，相对【坐标系0】的位姿齐次变换矩阵
Matrix4d WalkerKinematicsSolver::getEEPoseInC0(VectorXd q_expect)
{
	//连杆间旋转矩阵变量
	Matrix3d R1_0, R2_1, R3_2, R4_3, R5_4, R6_5, R7_6;
	Matrix3d R7_4, R3_0;

	//本正解算法是从最原始的、定义的关节坐标系零点开始计算的
	//所以给预期关节角要另加关节2、6处的原始offset
	VectorXd q_init_offset(7), q_from_zero(7);
	q_init_offset << -M_PI / 2, M_PI / 2, M_PI, 0, M_PI / 2, - M_PI / 2, 0;

	//计算从原点开始的关节转角
	q_from_zero = q_expect + q_init_offset;

	//求相邻旋转矩阵
	//注意：C++与MATLAB不同，计数序号从0开始
	R1_0 = calRotMatrix(q_from_zero(0), link1.alpha);
	R2_1 = calRotMatrix(q_from_zero(1), link2.alpha);
	R3_2 = calRotMatrix(q_from_zero(2), link3.alpha);
	R4_3 = calRotMatrix(q_from_zero(3), link4.alpha);
	R5_4 = calRotMatrix(q_from_zero(4), link5.alpha);
	R6_5 = calRotMatrix(q_from_zero(5), link6.alpha);
	R7_6 = calRotMatrix(q_from_zero(6), link7.alpha);

	//连乘求2个重要不相邻关节旋转矩阵
	R7_4 = R5_4 * R6_5 * R7_6;
	R3_0 = R1_0 * R2_1 * R3_2;

	//计算相对坐标系0的末端正解位姿
	Vector3d x7_0;
	x7_0 = lbs_0 + R3_0 * (lse_3 + R4_3 * (leo_4 + low_4 + R7_4 * lwt_7)); //位置
	Matrix3d R7_0;
	R7_0 = R3_0 * R4_3 * R7_4; //姿态

	//综合为7到0的齐次坐标
	Matrix4d T7_0;
	T7_0 << R7_0, x7_0, 0, 0, 0, 1; //矩阵连接

	//转换为夹爪相对于坐标系0的位姿
	Matrix4d Tgripper_0 = T7_0 * T_gripper_7;

	return Tgripper_0;
}

//左臂正解函数：相对base_link，输出齐次变换矩阵
//输入：左臂预期关节转角（从theta的初始offset处开始计算，代码自动将其转换为从坐标系零点开始的转角）
//返回：左臂末端相对base_link的位姿齐次变换矩阵
Matrix4d WalkerKinematicsSolver::getLeftEETransMatInBase(VectorXd q_expect)
{
	//调用【基本正解函数】获取左臂末端在左臂坐标系0中的位姿齐次变换矩阵
	Matrix4d T_leftGripper_left0;
	T_leftGripper_left0 = getEEPoseInC0(q_expect);

	//返回变换后的末端位姿
	Matrix4d T_leftGripper_base;
	T_leftGripper_base = T_left0_base * T_leftGripper_left0;

	return T_leftGripper_base;
}

//左臂正解函数：相对base_link，输出ROS geometry_msgs类型的位姿
//输入：左臂预期关节转角（从theta的初始offset处开始计算，代码自动将其转换为从坐标系零点开始的转角）
//返回：左臂末端相对base_link的geometry_msgs类型的位姿
geometry_msgs::Pose WalkerKinematicsSolver::getLeftEEPoseInBase(VectorXd q_expect)
{
	Matrix4d T = getLeftEETransMatInBase(q_expect);
	//将齐次变换矩阵转换为ros类型
	geometry_msgs::Pose pose;
	//位置可以直接赋值
	pose.position.x = T(0, 3); //取1行4列
	pose.position.y = T(1, 3); //取1行4列
	pose.position.z = T(2, 3); //取1行4列
	//姿态需要经过旋转矩阵转化为四元数
	Matrix3d R = T.block<3, 3>(0, 0); //取小块，从1行1列开始的三行三列
	//利用Eigen将R转换为四元数
	Quaterniond q(R); //用旋转矩阵初始化四元数，等价于转换
	//姿态赋值
	pose.orientation.x = q.x(); //务必注意Eigen四元数的储存顺序
	pose.orientation.y = q.y();
	pose.orientation.z = q.z();
	pose.orientation.w = q.w();

	return pose;
}

//获取左臂所有坐标系相对base_link的geometry_msgs类型位姿，用于碰撞检测时碰撞体位姿计算
//输入：左臂预期关节转角（从theta的初始offset处开始计算，代码自动将其转换为从坐标系零点开始的转角）
//返回：左臂所有坐标系位姿组成的向量
vector<geometry_msgs::Pose> WalkerKinematicsSolver::getLeftAllPoseInBase(VectorXd q_expect)
{
	//本正解算法是从最原始的、定义的关节坐标系零点开始计算的
	//所以给预期关节角要另加关节2、6处的原始offset
	VectorXd q_init_offset(7), q_from_zero(7);
	q_init_offset << -M_PI / 2, M_PI / 2, M_PI, 0, M_PI / 2, - M_PI / 2, 0;

	//计算从原点开始的关节转角
	q_from_zero = q_expect + q_init_offset;

	//给定关节角，计算各个连杆的齐次变换矩阵
	Matrix4d T1_0, T2_1, T3_2, T4_3, T5_4, T6_5, T7_6;
	T1_0 = calTransMatrix(q_from_zero(0), link1.d, link1.a, link1.alpha);
	T2_1 = calTransMatrix(q_from_zero(1), link2.d, link2.a, link2.alpha);
	T3_2 = calTransMatrix(q_from_zero(2), link3.d, link3.a, link3.alpha);
	T4_3 = calTransMatrix(q_from_zero(3), link4.d, link4.a, link4.alpha);
	T5_4 = calTransMatrix(q_from_zero(4), link5.d, link5.a, link5.alpha);
	T6_5 = calTransMatrix(q_from_zero(5), link6.d, link6.a, link6.alpha);
	T7_6 = calTransMatrix(q_from_zero(6), link7.d, link7.a, link7.alpha);

	//计算各连杆相对坐标系0的齐次变换矩阵
	Matrix4d T2_0, T3_0, T4_0, T5_0, T6_0, T7_0;
	T2_0 = T1_0 * T2_1;
	T3_0 = T2_0 * T3_2;
	T4_0 = T3_0 * T4_3;
	T5_0 = T4_0 * T5_4;
	T6_0 = T5_0 * T6_5;
	T7_0 = T6_0 * T7_6;

	vector<Matrix4d> all_transmats;
	all_transmats.push_back(T1_0);
	all_transmats.push_back(T2_0);
	all_transmats.push_back(T3_0);
	all_transmats.push_back(T4_0);
	all_transmats.push_back(T5_0);
	all_transmats.push_back(T6_0);
	all_transmats.push_back(T7_0);

	//此外加入末端抓手的位姿
	Matrix4d Tgripper_0;
	Tgripper_0 = T7_0 * T_gripper_7;
	all_transmats.push_back(Tgripper_0);
	
	vector<geometry_msgs::Pose> all_poses;
	for (int i=0; i<all_transmats.size(); ++i)
	{
		//转换为相对base_link的齐次矩阵
		Matrix4d Tx_base;
		Tx_base = T_left0_base * all_transmats[i];

		//转换为geometry_msgs::Pose类型位姿
		geometry_msgs::Pose pose;
		//位置可以直接赋值
		pose.position.x = Tx_base(0, 3); //取1行4列
		pose.position.y = Tx_base(1, 3); //取1行4列
		pose.position.z = Tx_base(2, 3); //取1行4列
		//姿态需要经过旋转矩阵转化为四元数
		Matrix3d R = Tx_base.block<3, 3>(0, 0); //取小块，从1行1列开始的三行三列
		//利用Eigen将R转换为四元数
		Quaterniond q(R); //用旋转矩阵初始化四元数，等价于转换
		//姿态赋值
		pose.orientation.x = q.x(); //务必注意Eigen四元数的储存顺序
		pose.orientation.y = q.y();
		pose.orientation.z = q.z();
		pose.orientation.w = q.w();

		all_poses.push_back(pose);
	}
	
	return all_poses;
}

//右臂正解函数：相对base_link，输出齐次变换矩阵
//输入：右臂预期关节转角（从theta的初始offset处开始计算，代码自动将其转换为从坐标系零点开始的转角）
//返回：右臂末端相对base_link的位姿齐次变换矩阵
Matrix4d WalkerKinematicsSolver::getRightEETransMatInBase(VectorXd q_expect)
{
	//调用【基本正解函数】获取右臂末端在右臂坐标系0中的位姿齐次变换矩阵
	Matrix4d T_rightGripper_right0;
	T_rightGripper_right0 = getEEPoseInC0(q_expect);

	//返回变换后的末端位姿
	Matrix4d T_rightGripper_base;
	T_rightGripper_base = T_right0_base * T_rightGripper_right0;

	return T_rightGripper_base;
}

//右臂正解函数：相对base_link，输出ROS geometry_msgs类型的位姿
//输入：右臂预期关节转角（从theta的初始offset处开始计算，代码自动将其转换为从坐标系零点开始的转角）
//返回：右臂末端相对base_link的geometry_msgs类型的位姿
geometry_msgs::Pose WalkerKinematicsSolver::getRightEEPoseInBase(VectorXd q_expect)
{
	Matrix4d T = getRightEETransMatInBase(q_expect);
	//将齐次变换矩阵转换为ros类型
	geometry_msgs::Pose pose;
	//位置可以直接赋值
	pose.position.x = T(0, 3); //取1行4列
	pose.position.y = T(1, 3); //取1行4列
	pose.position.z = T(2, 3); //取1行4列
	//姿态需要经过旋转矩阵转化为四元数
	Matrix3d R = T.block<3, 3>(0, 0); //取小块，从1行1列开始的三行三列
	//利用Eigen将R转换为四元数
	Quaterniond q(R); //用旋转矩阵初始化四元数，等价于转换
	//姿态赋值
	pose.orientation.x = q.x(); //务必注意Eigen四元数的储存顺序
	pose.orientation.y = q.y();
	pose.orientation.z = q.z();
	pose.orientation.w = q.w();
	
	return pose;
}

//获取右臂所有坐标系相对base_link的geometry_msgs类型位姿，用于碰撞检测时碰撞体位姿计算
//输入：右臂预期关节转角（从theta的初始offset处开始计算，代码自动将其转换为从坐标系零点开始的转角）
//返回：右臂所有坐标系位姿组成的向量
vector<geometry_msgs::Pose> WalkerKinematicsSolver::getRightAllPoseInBase(VectorXd q_expect)
{
	//本正解算法是从最原始的、定义的关节坐标系零点开始计算的
	//所以给预期关节角要另加关节2、6处的原始offset
	VectorXd q_init_offset(7), q_from_zero(7);
	q_init_offset << -M_PI / 2, M_PI / 2, M_PI, 0, M_PI / 2, - M_PI / 2, 0;

	//计算从原点开始的关节转角
	q_from_zero = q_expect + q_init_offset;

	//给定关节角，计算各个连杆的齐次变换矩阵
	Matrix4d T1_0, T2_1, T3_2, T4_3, T5_4, T6_5, T7_6;
	T1_0 = calTransMatrix(q_from_zero(0), link1.d, link1.a, link1.alpha);
	T2_1 = calTransMatrix(q_from_zero(1), link2.d, link2.a, link2.alpha);
	T3_2 = calTransMatrix(q_from_zero(2), link3.d, link3.a, link3.alpha);
	T4_3 = calTransMatrix(q_from_zero(3), link4.d, link4.a, link4.alpha);
	T5_4 = calTransMatrix(q_from_zero(4), link5.d, link5.a, link5.alpha);
	T6_5 = calTransMatrix(q_from_zero(5), link6.d, link6.a, link6.alpha);
	T7_6 = calTransMatrix(q_from_zero(6), link7.d, link7.a, link7.alpha);

	//计算各连杆相对坐标系0的齐次变换矩阵
	Matrix4d T2_0, T3_0, T4_0, T5_0, T6_0, T7_0;
	T2_0 = T1_0 * T2_1;
	T3_0 = T2_0 * T3_2;
	T4_0 = T3_0 * T4_3;
	T5_0 = T4_0 * T5_4;
	T6_0 = T5_0 * T6_5;
	T7_0 = T6_0 * T7_6;

	vector<Matrix4d> all_transmats;
	all_transmats.push_back(T1_0);
	all_transmats.push_back(T2_0);
	all_transmats.push_back(T3_0);
	all_transmats.push_back(T4_0);
	all_transmats.push_back(T5_0);
	all_transmats.push_back(T6_0);
	all_transmats.push_back(T7_0);

	//此外加入末端抓手的位姿
	Matrix4d Tgripper_0;
	Tgripper_0 = T7_0 * T_gripper_7;
	all_transmats.push_back(Tgripper_0);
	
	vector<geometry_msgs::Pose> all_poses;
	for (int i=0; i<all_transmats.size(); ++i)
	{
		//转换为相对base_link的齐次矩阵
		Matrix4d Tx_base;
		Tx_base = T_right0_base * all_transmats[i];   //和左臂的区别仅在于这一句

		//转换为geometry_msgs::Pose类型位姿
		geometry_msgs::Pose pose;
		//位置可以直接赋值
		pose.position.x = Tx_base(0, 3); //取1行4列
		pose.position.y = Tx_base(1, 3); //取1行4列
		pose.position.z = Tx_base(2, 3); //取1行4列
		//姿态需要经过旋转矩阵转化为四元数
		Matrix3d R = Tx_base.block<3, 3>(0, 0); //取小块，从1行1列开始的三行三列
		//利用Eigen将R转换为四元数
		Quaterniond q(R); //用旋转矩阵初始化四元数，等价于转换
		//姿态赋值
		pose.orientation.x = q.x(); //务必注意Eigen四元数的储存顺序
		pose.orientation.y = q.y();
		pose.orientation.z = q.z();
		pose.orientation.w = q.w();

		all_poses.push_back(pose);
	}
	
	return all_poses;
}

//基本解析反解函数：相对【坐标系0】，不直接使用，仅供左右臂反解函数调用
//输入：不分左右臂，【夹爪】相对【坐标系0】的位置向量和姿态矩阵，臂形角
//返回：不分左右臂，16组预期关节转角解（从theta的初始offset处开始计算的角度）
vector<VectorXd> WalkerKinematicsSolver::get16IkFromPoseInC0(Matrix4d Tgripper_0d, double psi)
{
	//将预期夹爪位姿转换为预期坐标系7的位姿
	Matrix4d T7_0d;
	T7_0d = Tgripper_0d * T_7_gripper;

	//齐次矩阵分解为平移向量和旋转矩阵
	Vector3d t7_0d;
	Matrix3d R7_0d;

	//分解为位置和姿态
	t7_0d = T7_0d.block<3, 1>(0, 3); //取小块
	R7_0d = T7_0d.block<3, 3>(0, 0); //取小块

	double SE = sqrt(pow(Dso, 2) + pow(Deo, 2)); //推理详情见文档
	double EW = sqrt(pow(Deo, 2) + pow(Dow, 2)); 
	double SW0 = Dso + Dow;

	//SW向量的坐标表示
	Vector3d Xsw_0 = t7_0d - lbs_0 - R7_0d * lwt_7;
	double SW = Xsw_0.norm(); //任意情况下Xsw_0的模长

	//求解theta40、theta4t
	double theta40 = acos((pow(SE, 2) + pow(EW, 2) - pow(SW0, 2)) / (2 * SE * EW));
	double theta4t = acos((pow(SE, 2) + pow(EW, 2) - pow(SW, 2)) / (2 * SE * EW));

	//求解theta4，实际只有2个解
	//但为了与后续R300解数对应，取为重复的4解，存入vector中便于迭代
	vector<double> theta4(4);
	theta4[0] = -(2 * M_PI - (theta40 + theta4t)); //反转解（walker实际只能反转）
	theta4[1] = theta4[0];						 //重复反转解（walker实际只能反转）
	theta4[2] = theta40 - theta4t;               //正转解
	theta4[3] = theta4[2];                       //重复正转解

	//求y300
	//计算公用值：alpha和beta
	double alpha = acos((pow(Dso, 2) + pow(SW, 2) - pow(Dow, 2)) / (2 * sqrt(pow(Dso, 2) + pow(Deo, 2)) * SW));
	double beta = atan2(Deo, Dso);

	//计算公用值：单位l向量及其反对称矩阵
	Vector3d l = lbs_0.cross(Xsw_0);	  //l向量
	Matrix3d Ul_hat = calAntiMatrix(l);   //计算l向量的单位反对称矩阵
	Matrix3d I3 = Matrix3d::Identity();   //定义一个单位矩阵
	//一些公用计算矩阵变量，避免多次计算
	Matrix3d Ul_hat_square = Ul_hat * Ul_hat;
	Vector3d Usw_0 = Xsw_0 / SW; //单位SW向量
	Matrix3d Usw_0_hat = calAntiMatrix(Xsw_0); //单位SW向量的反对称矩阵
	
	//根据罗德里格斯公式求y300的4组解
	//根据正反转以及z、l正反向状态的不同，旋转角Gamma共4种情况，存入向量
	vector<double> gamma(4);
	gamma[0] = alpha + beta;   //1. z300和l同向 + 肘关节反转情况：a + b
	gamma[1] = -alpha - beta;  //2. z300和l反向 + 肘关节反转情况：-(a + b)
	gamma[2] = alpha - beta;   //3. z300和l反向 + 肘关节正转情况：a - b
	gamma[3] = -alpha + beta;  //4. z300和l同向 + 肘关节正转情况：b - a

	//计算R_l临时旋转矩阵和y300向量对应4解都，放入vector，便于迭代
	vector<Matrix3d> R_l(4);
	vector<Vector3d> y300(4);
	for(int i=0; i<4; ++i)
	{
		R_l[i] = I3 + Ul_hat * sin(gamma[i]) + Ul_hat_square * (1 - cos(gamma[i]));
		y300[i] = -R_l[i] * Usw_0;
	}

	//计算4组z300，解序号与y300的取值保持一致
	vector<Vector3d> z300(4);
	z300[0] = l / l.norm();
	z300[1] = -z300[0];
	z300[2] = -z300[0];
	z300[3] = z300[0];

	//计算x300，解序号与另两者同样保持一致
	vector<Vector3d> x300(4);
	for(int i=0; i<4; ++i)
	{
		x300[i] = y300[i].cross(z300[i]);
	}

	//综合为R300，一共4解
	//将R300四解存入vector中便于后续迭代求解
	vector<Matrix3d> R300(4);
	for(int i=0; i<4; ++i)
	{
		R300[i] << x300[i], y300[i], z300[i];
	}

	//预先计算臂形角psi的正余弦值
	double cpsi = cos(psi);
	double spsi = sin(psi);

	//求解肩关节、腕关节，综合最终解
	//最终16组解的容器
	vector<VectorXd> ik_16_values; //不要初始化大小，否则不能使用push_back
	for (int i = 0; i < 4; ++i)
	{
		Matrix3d As = Usw_0_hat * R300[i];
		Matrix3d Bs = -Usw_0_hat * Usw_0_hat * R300[i];
		Matrix3d Cs = (Usw_0 * Usw_0.transpose()) * R300[i];
		
		//求给定臂形角下的R30
		Matrix3d R30_psi = As * spsi + Bs * cpsi + Cs;

		//取R30_psi矩阵特殊位上的元素
		//注意：Eigen元素序号从0开始！
		double M31 = R30_psi(2, 0);
		double M32 = R30_psi(2, 1);
		double M33 = R30_psi(2, 2);
		double M12 = R30_psi(0, 1);
		double M22 = R30_psi(1, 1);

		//求theta2、1、3的2组解
		vector<double> theta1(2), theta2(2), theta3(2);
		theta2[0] = acos(M32); //theta2有正负2值
		theta2[1] = -theta2[0];
		for (int j = 0; j < 2; ++j)
		{
			theta1[j] = atan2(-M22 * sin(theta2[j]), -M12 * sin(theta2[j]));
			theta3[j] = atan2(-M33 * sin(theta2[j]), M31 * sin(theta2[j]));
		}

		Matrix3d R4_3_psi = calRotMatrix(theta4[i], link4.alpha);
		Matrix3d R4_3_psi_transpose = R4_3_psi.transpose(); //避免重复计算
		Matrix3d Aw = R4_3_psi_transpose * As.transpose() * R7_0d;
		Matrix3d Bw = R4_3_psi_transpose * Bs.transpose() * R7_0d;
		Matrix3d Cw = R4_3_psi_transpose * Cs.transpose() * R7_0d;

		//求给定臂形角下的R74
		Matrix3d R74_psi = Aw * spsi + Bw * cpsi + Cw;

		//取R74_psi矩阵特殊位上的元素
		//注意：Eigen元素序号从0开始！
		double W13 = R74_psi(0, 2);
		double W23 = R74_psi(1, 2);
		double W31 = R74_psi(2, 0);
		double W32 = R74_psi(2, 1);
		double W33 = R74_psi(2, 2);

		//求theta6、5、7的2组解
		vector<double> theta5(2), theta6(2), theta7(2);
		theta6[0] = acos(W33); //theta6有正负2值
		theta6[1] = -theta6[0];
		for (int j = 0; j < 2; ++j)
		{
			theta5[j] = atan2(W23 * sin(theta6[j]), W13 * sin(theta6[j]));
			theta7[j] = atan2(W32 * sin(theta6[j]), -W31 * sin(theta6[j]));
		}

		//综合所有解
		VectorXd joint_value_temp(7); 
		for (int j = 0; j < 2; ++j) //关于theta2系列的迭代
		{
			for (int k = 0; k < 2; k++) //关于theta6系列的迭代
			{   //                   各计算关节角减去关节初始Offset才是最终预期转角
				joint_value_temp(0) = theta1[j] - (-M_PI / 2);
				joint_value_temp(1) = theta2[j] - (M_PI / 2);
				joint_value_temp(2) = theta3[j] - M_PI;
				joint_value_temp(3) = theta4[i];
				joint_value_temp(4) = theta5[k] - (M_PI / 2);
				joint_value_temp(5) = theta6[k] - (-M_PI / 2);
				joint_value_temp(6) = theta7[k];
				ik_16_values.push_back(joint_value_temp);
			}
		}
	}

	return ik_16_values;
}

//左臂解析反解函数：相对【base_link】
//输入：左臂【夹爪】相对【base_link】的位置向量和姿态矩阵，臂形角
//返回：左臂16组预期关节转角解（从theta的初始offset处开始计算的角度）
vector<VectorXd> WalkerKinematicsSolver::getLeft16IkFromPoseInBase(Matrix4d T_leftGripper_base_d, double psi)
{
	//将输入的夹爪相对base的位姿转换为相对坐标系0的位姿
	Matrix4d T_leftGripper_left0_d;
	T_leftGripper_left0_d = T_base_left0 * T_leftGripper_base_d;

	//调用基本反解函数，获得16组解
	vector<VectorXd> left_ik_16_values;
	left_ik_16_values = get16IkFromPoseInC0(T_leftGripper_left0_d, psi);

	return left_ik_16_values;
}

//右臂解析反解函数：相对【base_link】
//输入：右臂【夹爪】相对【base_link】的位置向量和姿态矩阵，臂形角
//返回：右臂16组预期关节转角解（从theta的初始offset处开始计算的角度）
vector<VectorXd> WalkerKinematicsSolver::getRight16IkFromPoseInBase(Matrix4d T_rightGripper_base_d, double psi)
{
	//将输入的夹爪相对base的位姿转换为相对坐标系0的位姿
	Matrix4d T_rightGripper_right0_d;
	T_rightGripper_right0_d = T_base_right0 * T_rightGripper_base_d;

	//调用基本反解函数，获得16组解
	vector<VectorXd> right_ik_16_values;
	right_ik_16_values = get16IkFromPoseInC0(T_rightGripper_right0_d, psi);

	return right_ik_16_values;
}

//左臂关节角合理性验证函数
//输入：左臂关节角
//返回：是否超限
bool WalkerKinematicsSolver::leftJointCheck(VectorXd left_value)
{
	bool is_available = false;
	if (left_value(0) > -0.7854 && left_value(0) < 3.1416 &&
		left_value(1) > -1.5708 && left_value(1) < 0.0175 &&
		left_value(2) > -1.9199 && left_value(2) < 1.9199 &&
		left_value(3) > -2.2340 && left_value(3) < 0.0000 &&
		left_value(4) > -2.3562 && left_value(4) < 2.3562 &&
		left_value(5) > -0.3508 && left_value(5) < 0.3508 &&
		left_value(6) > -0.3508 && left_value(6) < 0.3508)
	{
		is_available = true;
	}
	return is_available;
}

//右臂关节角合理性验证函数
//输入：右臂关节角
//返回：是否超限
bool WalkerKinematicsSolver::rightJointCheck(VectorXd right_value)
{
	bool is_available = false;
	if (right_value(0) > -3.1416 && right_value(0) < 0.7854 &&
		right_value(1) > -1.5708 && right_value(1) < 0.0175 &&
		right_value(2) > -1.9199 && right_value(2) < 1.9199 &&
		right_value(3) > -2.2340 && right_value(3) < 0.0000 &&
		right_value(4) > -2.3562 && right_value(4) < 2.3562 &&
		right_value(5) > -0.3508 && right_value(5) < 0.3508 &&
		right_value(6) > -0.3508 && right_value(6) < 0.3508)
	{
		is_available = true;
	}

	return is_available;
}

//高层——左臂臂形角迭代直至获取最优反解结果，geometry_msg类型位姿
//输入：左臂【夹爪】相对【base_link】的geometry_msg类型位姿，存放反解结果的容器
//输出：若未超限，输出左臂的一组最优反解关节角（从theta的初始offset处开始计算的角度）
//返回：反解成功/失败
bool WalkerKinematicsSolver::getLeftBestIkFromPoseInBase(geometry_msgs::Pose left_gripper_pose, VectorXd &left_ik_value)
{
	//把输入的geometry_msgs::Pose类型的位姿转换为位置向量和旋转矩阵
	Vector3d t_leftGripper_base_d;
	t_leftGripper_base_d << left_gripper_pose.position.x, left_gripper_pose.position.y, left_gripper_pose.position.z;

	//利用Eigen把四元数转旋转矩阵
	//注意Eigen四元数的赋值顺序是WXYZ，输出顺序是XYZW
	Quaterniond q(left_gripper_pose.orientation.w, left_gripper_pose.orientation.x, left_gripper_pose.orientation.y,left_gripper_pose.orientation.z);
	Matrix3d R_leftGripper_base_d;
	R_leftGripper_base_d = q.toRotationMatrix();

	//组合为抓手相对base的齐次变换矩阵
	Matrix4d T_leftGripper_base_d;
	T_leftGripper_base_d << R_leftGripper_base_d, t_leftGripper_base_d, 0, 0, 0, 1;

	//求最优臂形角(暂无)

	//验证最优臂形角下是否有可行解(暂无)

	//若无可行解，开始循环迭代直至找到解
	double psi = -M_PI;

	vector<VectorXd> left_ik_available; //存放所有可用解的容器

	for (int j = 0; ; ++j)
	{
		if (psi > M_PI)
		{
			break;
		}

		//调用获取中层反解函数，获得全部16组解
		vector<VectorXd> left_ik_16_values;
		left_ik_16_values = getLeft16IkFromPoseInBase(T_leftGripper_base_d, psi);

		//获取未超限的解，放入容器
		for (int i = 0; i < left_ik_16_values.size(); ++i)
		{
			if (leftJointCheck(left_ik_16_values[i])) //16个解送入超限检查函数，没超限的话记录序号
			{
				left_ik_available.push_back(left_ik_16_values[i]);
			}
		}

		psi = psi + 0.2;
	}

	// cout << "迭代可行解数：" << left_ik_available.size()<< endl;
	if(left_ik_available.empty())
	{
		// cout << "未找到解！" << endl;
		return false;  //return后后续代码不会执行
	}
		
	//在可行解中找出距离各关节中心点最近的解，作为最优解输出
	//计算左臂关节转动限制中线值
	VectorXd left_arm_center(7);
	left_arm_center << 1.1781, -0.77665, 0, -1.117, 0, 0, 0; //中线值

	//计算所有可行解与中线值的差值向量的模，存入向量
	vector<double> diff_norm;
	for(int i=0; i<left_ik_available.size(); ++i)
	{
		diff_norm.push_back((left_ik_available[i]-left_arm_center).norm()); //求差值向量的模，存入vector便于找到最小值索引
		//cout << diff_norm[i] << endl; 
	}

	//找出最小值及其索引
	vector<double>::iterator smallest = min_element(diff_norm.begin(), diff_norm.end());
	int smallest_index = distance(diff_norm.begin(), smallest);

	//将最小索引对应的关节角赋值输出
    left_ik_value = left_ik_available[smallest_index];

	return true;
}

//高层——右臂臂形角迭代直至获取最优反解结果，geometry_msg类型位姿
//输入：右臂【夹爪】相对【base_link】的geometry_msg类型位姿，存放反解结果的容器
//输出：若未超限，输出右臂的一组最优反解关节角（从theta的初始offset处开始计算的角度）
//返回：反解成功/失败
bool WalkerKinematicsSolver::getRightBestIkFromPoseInBase(geometry_msgs::Pose right_gripper_pose, VectorXd &right_ik_value)
{
	//把输入的geometry_msgs::Pose类型的位姿转换为位置向量和旋转矩阵
	Vector3d t_rightGripper_base_d;
	t_rightGripper_base_d << right_gripper_pose.position.x, right_gripper_pose.position.y, right_gripper_pose.position.z;

	//利用Eigen把四元数转旋转矩阵
	//注意Eigen四元数的赋值顺序是WXYZ，输出顺序是XYZW
	Quaterniond q(right_gripper_pose.orientation.w, right_gripper_pose.orientation.x, right_gripper_pose.orientation.y, right_gripper_pose.orientation.z);
	Matrix3d R_rightGripper_base_d;
	R_rightGripper_base_d = q.toRotationMatrix();

	//组合为抓手相对base的齐次变换矩阵
	Matrix4d T_leftGripper_base_d;
	T_leftGripper_base_d << R_rightGripper_base_d, t_rightGripper_base_d, 0, 0, 0, 1;

	//求最优臂形角

	//验证最优臂形角下是否有可行解

	//若无可行解，开始循环迭代直至找到解
	double psi = -M_PI;
	vector<VectorXd> right_ik_available; //存放所有可用解的容器

	for (int j = 0; ; ++j)
	{
		if (psi > M_PI)
		{
			break;
		}

		//调用获取中层反解函数，获得全部16组解
		vector<VectorXd> right_ik_16_values;
		right_ik_16_values = getRight16IkFromPoseInBase(T_leftGripper_base_d, psi);

		//获取未超限的解，放入容器
		for (int i = 0; i < right_ik_16_values.size(); ++i)
		{
			if (rightJointCheck(right_ik_16_values[i])) //16个解送入超限检查函数，没超限的话记录序号
			{
				right_ik_available.push_back(right_ik_16_values[i]);
			}
		}

		psi = psi + 0.2;
	}

	// cout << "迭代可行解数：" << right_ik_available.size()<< endl;
	if(right_ik_available.empty())
	{
		// cout << "未找到可行解！" << endl;
		return false;  //return后后续代码不会执行
	}
		
	//在可行解中找出距离各关节中心点最近的解，作为最优解输出
	//计算右臂关节转动限制中线值
	VectorXd right_arm_center(7);
	right_arm_center << -1.1781, -0.77665, 0, -1.117, 0, 0, 0; //中线值

	//计算所有可行解与中线值的差值向量的模，存入向量
	vector<double> diff_norm;
	for(int i=0; i<right_ik_available.size(); ++i)
	{
		diff_norm.push_back((right_ik_available[i]-right_arm_center).norm()); //求差值向量的模，存入vector便于找到最小值索引
		//cout << diff_norm[i] << endl; 
	}

	//找出最小值及其索引
	vector<double>::iterator smallest = min_element(diff_norm.begin(), diff_norm.end());
	int smallest_index = distance(diff_norm.begin(), smallest);

	//将最小索引对应的关节角赋值输出
    right_ik_value = right_ik_available[smallest_index];

	return true;
}