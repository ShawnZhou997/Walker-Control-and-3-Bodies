# CMAKE generated file: DO NOT EDIT!
# Timestamp file for custom commands dependencies management for ubt_core_msgs_generate_messages_eus.
