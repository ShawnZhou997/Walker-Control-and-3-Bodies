# CMAKE generated file: DO NOT EDIT!
# Timestamp file for custom commands dependencies management for _ubt_core_msgs_generate_messages_check_deps_EndpointStates.
