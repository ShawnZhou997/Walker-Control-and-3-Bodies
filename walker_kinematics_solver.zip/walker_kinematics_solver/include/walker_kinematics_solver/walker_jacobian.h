#ifndef WALKER_JACOBIAN
#define WALKER_JACOBIAN

#include <vector>
#include <Eigen/Dense>
#include <geometry_msgs/Pose.h>
#include <math.h>
#include "walker_kinematics_solver/walker_kinematics_solver.h"

namespace WalkerJacobian
{
    Eigen::MatrixXd calRightC7JacobianInBase(WalkerKinematicsSolver &solver, VectorXd joint_angles);

    Eigen::MatrixXd calLeftC7JacobianInBase(WalkerKinematicsSolver &solver, VectorXd joint_angles);

    Eigen::MatrixXd calRightEEJacobianInBase(WalkerKinematicsSolver &solver, VectorXd joint_angles);
    
    Eigen::MatrixXd calLeftEEJacobianInBase(WalkerKinematicsSolver &solver, VectorXd joint_angles);

    // 计算伪逆
    template<typename _Matrix_Type_>
    _Matrix_Type_ pseudoInverse(const _Matrix_Type_ &a, double epsilon = std::numeric_limits<double>::epsilon())
    {
        // For a non-square matrix
        // Eigen::JacobiSVD< _Matrix_Type_ > svd(a ,Eigen::ComputeFullU | Eigen::ComputeFullV);
    
        Eigen::JacobiSVD< _Matrix_Type_ > svd(a ,Eigen::ComputeThinU | Eigen::ComputeThinV);
        double tolerance = epsilon * std::max(a.cols(), a.rows()) *svd.singularValues().array().abs()(0);
        return svd.matrixV() *  (svd.singularValues().array().abs() > tolerance).select(svd.singularValues().array().inverse(), 0).matrix().asDiagonal() * svd.matrixU().adjoint();
    }

}

#endif